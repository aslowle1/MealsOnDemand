//
//  ViewController.swift
//  MealsOnDemand
//
//  Created by Andros on 10/22/26.
//

import UIKit

/*
 
 a) - Complete
 b) - Need Help
 
 1) Get Text from searchbar
 2) Use that text as input for mealsFetcher call to server(getAllMeals)
 3) Via callback set view controller property “meals” to the results of mealsFetcher call
 4) Call reloadTableView


 */

class ViewController: UIViewController, UITableViewDataSource{
    
    var meals: [Meal] = []
    
    let mealFetcher = MealFetcher()

    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var mealSearchBar: UISearchBar!
    
    @IBAction func startSearch(_ sender: UIButton) {
        guard let searchedFood = mealSearchBar.text else {
            return
        }
        
        guard !searchedFood.isEmpty else { return }
        
        mealFetcher.getMealsFromFood(searchedFood) { incomingMeals in
            DispatchQueue.main.async {
                self.meals = incomingMeals
                self.tableView.reloadData()
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let mealsNib = UINib(nibName: "MealCell", bundle: nil)
        tableView.register(mealsNib, forCellReuseIdentifier: "meals")
        
        tableView.dataSource = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return meals.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "meals", for: indexPath) as? MealCell else {
            return UITableViewCell()
        }
        
        cell.mealsName.text = meals[indexPath.row].strMeal
        return cell
    }
}

