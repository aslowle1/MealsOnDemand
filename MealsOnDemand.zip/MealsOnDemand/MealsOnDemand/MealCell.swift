//
//  MealCell.swift
//  MealsOnDemand
//
//  Created by Andros on 10/29/26.
//

import UIKit

class MealCell: UITableViewCell {

    @IBOutlet weak var mealsName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
