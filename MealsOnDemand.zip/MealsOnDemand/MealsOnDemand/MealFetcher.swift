//
//  MealFetcher.swift
//  MealsOnDemand
//
//  Created by Andros on 10/22/26.
//

import Foundation

/*
 Create a function called “getMealsFromFood” that accepts a food(string) and also accepts a closure of type [Meal] -> Void
 You must use url session
 2 properties
 String
 Closure [meal] and returns no value

 */

class MealFetcher {
    /// https://www.themealdb.com/api/json/v1/1/search.php?s=pizza
    func createURLForFood(_ food: String) -> URL? {
        let strURL =  "https://www.themealdb.com/api/json/v1/1/search.php"
        
        var url = URL(string: strURL)
        
        let queryItem = URLQueryItem(name: "s", value: food)
        
        url?.append(queryItems: [queryItem])
        
        return url
    }
    
    typealias Completion = ([Meal]) -> Void
    
    func getMealsFromFood(_ food: String, completion: @escaping Completion) {
        guard let url = createURLForFood(food) else { return }
        
        let session = URLSession.shared
        
        let task = session.dataTask(with: url) { data, response, error in
            guard let data, let result = Result.getMealsFromData(data) else {
                return
            }
            
            let meals = result.meals
            
            completion(meals)
        }
        
        task.resume()
    }
}
