//
//  Result.swift
//  MealsOnDemand
//
//  Created by Andros on 10/22/26.
//

import Foundation

/*
 Create Result.swift - DOne
 Create Result struct - Done
 Hint: Also create a Meal type
 {
    "meals": [
      {
        "idMeal": "52771",
        "strMeal": "Spicy Arrabiata Penne",
        "strInstructions": "Bring a large pot of water to a boil…..",
        "strMealThumb": "https://www.themealdb.com/images/media/meals/ustsqw1468250014.jpg",
      }
    ]
  }

 */


struct Meal: Codable {
    let idMeal: String
    let strMeal: String
    let strInstructions: String
    let strMealThumb: String
}

struct Result: Codable {
    var meals: [Meal]
    
    static func getMealsFromData(_ data: Data) -> Result? {
        let jsonDecoder = JSONDecoder()
        
        do {
            return try jsonDecoder.decode(Result.self, from: data)
        } catch {
            print("Unable To Convert Data \(error.localizedDescription)")
            return nil
        }
    }
}
